package testSparkSQLMLlibRS;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.recommendation.ALS;
import org.apache.spark.ml.recommendation.ALSModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

public class TestSparkSQLMLlibRSALS {
	private static final String NAME = "JavaSQLMLlib";

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "c:\\winutil\\");
		System.setProperty("spark.sql.warehouse.dir",
				"file:///${System.getProperty(\"user.dir\")}/spark-warehouse".replaceAll("\\\\", "/"));

		// 1. Definir un SparkContext

		String master = System.getProperty("spark.master");
		SparkConf sconf = new SparkConf().setAppName(NAME).setMaster(master == null ? "local[*]" : master);
		JavaSparkContext ctx = new JavaSparkContext(sconf);
		SQLContext sql = SQLContext.getOrCreate(ctx.sc());

		// 2. Resolver nuestro problema

		Dataset<Row> dataset = sql.read().option("header", true).option("inferSchema", true)
				.json("resources//data.json");

		ALS als = new ALS().setMaxIter(5).setRegParam(0.01).setUserCol("userId").setItemCol("itemId")
				.setRatingCol("rating");
		ALSModel model = als.fit(dataset);
		Dataset<Row> completa = dataset.select(dataset.col("userId")).distinct()
				.join(dataset.select(dataset.col("itemId")).distinct());
		completa = model.transform(completa);
		completa.show();
		completa.write().json("C://Users//Juan//Documents//FitnGrow//Hadoop//json");
		ctx.stop();
		ctx.close();
	}
}