package testSparkSQLMLlibRS;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.AnalysisException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

public class TestSparkSQLMLlibRSContentBased {
	private static final String NAME = "JavaSQLMLlib2";

	public static void main(String[] args) throws AnalysisException {
		System.setProperty("hadoop.home.dir", "c:\\winutil\\");
		System.setProperty("spark.sql.warehouse.dir",
				"file:///${System.getProperty(\"user.dir\")}/spark-warehouse".replaceAll("\\\\", "/"));

		// 1. Definir un SparkContext

		String master = System.getProperty("spark.master");
		SparkConf sconf = new SparkConf().setAppName(NAME).setMaster(master == null ? "local[*]" : master);
		JavaSparkContext ctx = new JavaSparkContext(sconf);
		SQLContext sql = SQLContext.getOrCreate(ctx.sc());

		// 2. Resolver nuestro problema

		Dataset<Row> dataset = sql.read().option("inferSchema", true).json("resources//data.json");

		dataset.select(dataset.col("userId").as("user1"), dataset.col("itemId").as("film1"))
				.join(dataset.select(dataset.col("userId").as("user2"), dataset.col("itemId").as("film2")))
				.where("user1 = user2").where("film1 <> film2").select("film1", "film2").write()
				.json("C://Users//Juan//Documents//FitnGrow//Hadoop//json2");

		JavaRDD<Row> result = dataset.select(dataset.col("userId").as("user1"), dataset.col("itemId").as("film1"))
				.join(dataset.select(dataset.col("userId").as("user2"), dataset.col("itemId").as("film2")))
				.where("user1 = user2").where("film1 <> film2").select("film1", "film2").javaRDD();

		result.saveAsTextFile("C://Users//Juan//Documents//FitnGrow//Hadoop//json3");

		// 3. Liberar recursos

		ctx.stop();
		ctx.close();
	}
}