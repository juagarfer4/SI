package clusAs;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.clustering.KMeans;
import org.apache.spark.mllib.clustering.KMeansModel;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

public class CustomerSegmentation {

	private static final String NAME = "JavaSQLMLlib";
	private static final Integer MAX_ITER = 10;
	private static final Integer SEED = 10;
	private static final Integer K = 5;

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "c:\\winutil\\");
		System.setProperty("spark.sql.warehouse.dir",
				"file:///${System.getProperty(\"user.dir\")}/spark-warehouse".replaceAll("\\\\", "/"));

		// 1. Definir un SparkContext

		String master = System.getProperty("spark.master");
		SparkConf sconf = new SparkConf().setAppName(NAME).setMaster(master == null ? "local[*]" : master);
		JavaSparkContext ctx = new JavaSparkContext(sconf);
		SQLContext sql = SQLContext.getOrCreate(ctx.sc());

		// 2. Resolver nuestro problema

		Dataset<Row> users = sql.read().option("inferSchema", true).json("resources//u.json");

		JavaRDD<Vector> jrdd = new JavaRDD<Row>(users.rdd(), users.org$apache$spark$sql$Dataset$$classTag())
				.map(x -> Vectors.dense(x.getLong(0) * .1));

		// Cluster the data into two classes using KMeans
		KMeansModel clusters = new KMeans().setSeed(SEED).setK(K).setMaxIterations(MAX_ITER).run(jrdd.rdd());

		System.out.println(Arrays.toString(clusters.clusterCenters()));

		// 3. Liberar recursos

		ctx.stop();
		ctx.close();
	}

}