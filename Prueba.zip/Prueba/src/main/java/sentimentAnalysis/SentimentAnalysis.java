package sentimentAnalysis;

import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.util.CoreMap;
import scala.Tuple2;

public class SentimentAnalysis {
	private static final String PATH = "C://Users//Juan//Documents//FitnGrow//Hadoop";

	public static void main(String[] args) throws Exception {
		System.setProperty("hadoop.home.dir", "c:\\winutil\\");
		System.setProperty("spark.sql.warehouse.dir",
				"file:///${System.getProperty(\"user.dir\")}/spark-warehouse".replaceAll("\\\\", "/"));

		// 1. Definir el objeto configurador de Spark
		String master = System.getProperty("spark.master");
		SparkConf sc = new SparkConf().setAppName("StreamingTwitter").setMaster(master == null ? "local[2]" : master);
		JavaSparkContext ctx = new JavaSparkContext(sc);

		// 2. Resolver nuestro problema
		JavaStreamingContext ssc = new JavaStreamingContext(ctx, new Duration(10000));
		JavaDStream<String> stream = ssc.textFileStream(PATH);
		SQLContext sql = SQLContext.getOrCreate(ctx.sc());

		stream.foreachRDD(rdd -> {
			JavaRDD<Tuple2<String, Double>> data = rdd.map(x -> new Tuple2<String, Double>(x, getScore(x)));
			Dataset<Tuple2<String, Double>> dataset = sql.createDataset(data.rdd(),
					Encoders.tuple(Encoders.STRING(), Encoders.DOUBLE()));
			dataset.show();
			dataset.write().mode("append").json("C://Users//Juan//Documents//FitnGrow//Hadoop/json");
		});

		// 3. Abrir el canal
		ssc.start();
		ssc.awaitTermination();
		ssc.close();
	}

	public static Double getScore(String line) throws Exception {

		Long textLength = 0L;
		int sumOfValues = 0;
		Properties props = new Properties();
		props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);
		if (line != null && line.length() > 0) {
			int longest = 0;
			Annotation annotation = pipeline.process(line);
			for (CoreMap sentence : annotation.get(CoreAnnotations.SentencesAnnotation.class)) {
				Tree tree = sentence.get(SentimentCoreAnnotations.SentimentAnnotatedTree.class);
				int sentiment = RNNCoreAnnotations.getPredictedClass(tree);
				String partText = sentence.toString();
				if (partText.length() > longest) {
					textLength += partText.length();
					sumOfValues = sumOfValues + sentiment * partText.length();
				}
			}
		}

		return (double) sumOfValues / textLength;
	}

}
