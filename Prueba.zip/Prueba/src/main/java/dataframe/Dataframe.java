package dataframe;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;

public class Dataframe {
	private static final String NAME = "Dataframe";

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "c:\\winutil\\");
		System.setProperty("spark.sql.warehouse.dir",
				"file:///${System.getProperty(\"user.dir\")}/spark-warehouse".replaceAll("\\\\", "/"));

		// 1. Definir un SparkContext

		String master = System.getProperty("spark.master");
		SparkConf sconf = new SparkConf().setAppName(NAME).setMaster(master == null ? "local" : master);
		JavaSparkContext ctx = new JavaSparkContext(sconf);
		SQLContext sql = SQLContext.getOrCreate(ctx.sc());
		// 2. Resolver nuestro problema

		Dataset<Row> dataset = sql.read().option("header", true).option("inferSchema", true)
				.csv("resources//manufacturer.csv");
		Dataset<Row> manufacturas = dataset.select(dataset.col("Manufacturer")).distinct();

		dataset.printSchema();
		manufacturas.show();

		// 3. Liberar recursos

		ctx.stop();
		ctx.close();

	}

}
